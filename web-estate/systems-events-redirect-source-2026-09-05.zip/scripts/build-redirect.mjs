import fs from 'node:fs';
fs.rmSync('dist',{recursive:true,force:true});
fs.mkdirSync('dist/server',{recursive:true});
fs.copyFileSync('redirect-worker.mjs','dist/server/index.js');
