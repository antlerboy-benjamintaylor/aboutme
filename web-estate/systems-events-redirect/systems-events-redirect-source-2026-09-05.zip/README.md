# Systems events: canonical public home

The public interface now lives at https://transduction.systems/events/. This existing hosted address and the planned events.transduction.systems vanity address return permanent redirects to that canonical home, preserving paths and query strings. The daily collector, source register, stable calendar feeds, and review queue remain in antlerboy/systemsmap.

Build with `npm run build`. The collector source preserved in this repository is historical; continue collector work in the maintained GitHub systemsmap repository.
