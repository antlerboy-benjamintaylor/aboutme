const canonical='https://transduction.systems/events/';
export default {
 async fetch(request) {
  const incoming=new URL(request.url);
  if(request.method!=='GET'&&request.method!=='HEAD')return new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}});
  const suffix=incoming.pathname.replace(/^\/+/, '').replace(/^events\/?/, '');
  const target=new URL(suffix,canonical);
  target.search=incoming.search;
  // All destinations remain under the fixed canonical origin.
  if(target.origin!=='https://transduction.systems')return new Response('Invalid path',{status:400});
  return new Response(null,{status:301,headers:{Location:target.href,'Cache-Control':'public, max-age=300'}});
 }
};
